/* Añadir la clase active a los elementos con id sidebar y overlay */
function activarSideBar() 
{
}

/* Quitar la clase active a los elementos con id sidebar y overlay */
function desactivarSideBar() 
{
}