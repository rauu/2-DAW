var dataBarProducto1_19 = [748, 149, 1590, 519];
var dataBarProducto2_19 = [1000, 900, 800, 700];
var dataBarProducto3_19 = [419, 219, 79, 2105];
var dataBarProducto1_20 = [133, 221, 783, 2478];
var dataBarProducto2_20 = [408, 547, 675, 734];
var dataBarProducto3_20 = [348, 264, 948, 3159];

var areaBarA_19 = [47, 16, 27, 94, 78];
var areaBarB_19 = [27, 98, 76, 87, 15];
var areaBarA_20 = [65, 75, 70, 80, 60];
var areaBarB_20 = [54, 65, 60, 70, 70];

var percentil25_DWEC = [4, 4, 4, 4];
var percentil25_DWES = [5.125, 5.125, 5.125, 5.125];
var percentil50_DWEC = [6.5, 6.5, 6.5, 6.5];
var percentil50_DWES = [6, 6, 6, 6];
var percentil75_DWEC = [9, 9, 9, 9];
var percentil75_DWES = [7.625, 7.625, 7.625, 7.625];
var notas_DWEC = [5.5, 7.5, 9.5, 3.5];
var notas_DWES = [8, 5, 5.5, 6.5];

var percentil25_DWEC_19 = [2.25, 2.25, 2.25, 2.25];
var percentil25_DWES_19 = [3.875, 3.875, 3.875, 3.875];
var percentil50_DWEC_19 = [5.75, 5.75, 5.75, 5.75];
var percentil50_DWES_19 = [6.5, 6.5, 6.5, 6.5];
var percentil75_DWEC_19 = [7.75, 7.75, 7.75, 7.75];
var percentil75_DWES_19 = [9.125, 9.125, 9.125, 9.125];
var notas_DWEC_19 = [7, 4.5, 8, 1.5];
var notas_DWES_19 = [5, 8, 9.5, 3.5];

var doughnut_19 = [1790, 7516, 1749, 320, 2791];
var doughnut_20 = [2478, 5267, 734, 784, 433];