<?php
require_once ('Jugador.php');

class Escolta extends Jugador
{
    private $puntos;


    public function __construct($row)
    {
        parent::__construct($row);
        $this->puntos = $row['puntos'];
    }


    public function __get($name)
    {
        switch ($name) {
            case 'puntos':
                return $this->puntos;
            default:
                return parent::__get($name);
        }
    }

    public function __set($name, $value)
    {
        switch ($name) {
            case 'puntos':
                $this->puntos = $value;
                break;
        }
    }
    public function __toString(){
        return "Puntos: ".$this->puntos;
    }
}
?>