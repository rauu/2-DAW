<?php


 abstract class Jugador{
    private $dorsal;
    private $nombre;
    private $estatura;



    public function __construct($row){
        $this-> dorsal = $row['dorsal'];
        $this-> nombre = $row['nombre'];
        $this-> estatura = $row['estatura'];
    }

    public function __get($name)
    {
        switch ($name) {
            case 'dorsal':
                return $this->dorsal;
            case 'nombre':
                return $this->nombre;
            case 'estatura':
                return $this->estatura;
        }
    }

    public function __set($name, $value){
        switch($name){
            case 'dorsal':
                $this->dorsal = $value;
                break;
            case 'nombre':
                $this->nombre = $value;
                break;
            case 'estatura':
                $this->estatura = $value;
        }
    }
   

}

?>