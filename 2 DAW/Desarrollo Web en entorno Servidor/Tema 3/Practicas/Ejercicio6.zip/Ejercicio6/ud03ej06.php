<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Ejercicio 6</title>
</head>

<body>
    <?php
    require_once("Jugador.php");
    require_once('AlaPivot.php');
    require_once('Alero.php');
    require_once('Base.php');
    require_once('Equipo.php');
    require_once('Escolta.php');

    require_once('Pivot.php');

    $jugador1 = new AlaPivot(['dorsal' => '01', 'nombre'  => "Raunak", "estatura" => 175, "tapones" => "50"]);
    $jugador2 = new Alero(['dorsal' => '02', 'nombre'  => "Victor", "estatura" => 170, "robos" => "60"]);
    $jugador3 = new Base(['dorsal' => '03', 'nombre'  => "Jesus", "estatura" => 175, "asistencias" => "30"]);
    $jugador4 = new Escolta(['dorsal' => '04', 'nombre'  => "Lucia", "estatura" => 180, "puntos" => "10"]);
    $jugador5 = new Pivot(['dorsal' => '05', 'nombre'  => "Alejandro", "estatura" => 190, "rebotes" => "30"]);

    $equipo1 = new Equipo('equipo1', array($jugador1, $jugador2, $jugador3, $jugador4, $jugador5));
    // print_r($equipo1);
    
    echo "<br><br><br><br><br><br>";

    echo "<p id=\"p\">La Estatura media es: " . $equipo1->estaturaMedia($equipo1->jugador) . " cm.</p>";
    echo "<p id=\"p\">La Estatura maxima es: " . $equipo1->estaturaMaxima($equipo1->jugador) . " cm.</p>";

    echo "<table border>";
    echo "<th>";
    echo "Dorsal";
    echo "</th>";
    echo "<th>";
    echo "Nombre";
    echo "</th>";
    echo "<th>";
    echo "Estatura";
    echo "</th>";
    echo "<th>";
    echo "Otras Especificaciones";
    echo "</th>";
    foreach ($equipo1->jugador as $x) {


        echo "<tr>";
        echo "<td>" . $x->dorsal . "</td>";
        echo "<td>" . $x->nombre . "</td>";
        echo "<td>" . $x->estatura . "</td>";
       
            echo "<td>" . $x . "</td>";
       
            
        
        
    }
    echo "</table>";


    ?>

    <style>
        th,
        td {
            padding: 10px;
        }

        table {
            margin: auto;
            text-align: center;
        }
        #p{
            text-align: center;
        }
    </style>
</body>

</html>