<?php
require_once('Jugador.php');

class Pivot extends Jugador
{
    private $rebotes;


    public function __construct($row)
    {
        parent::__construct($row);
        $this->rebotes = $row['rebotes'];
    }


    public function __get($name)
    {
        switch ($name) {
            case 'rebotes':
                return $this->rebotes;
            default:
                return parent::__get($name);
        }
    }

    public function __set($name, $value)
    {
        switch ($name) {
            case 'rebotes':
                $this->rebotes = $value;
                break;
        }
    }
    public function __toString(){
        return "Rebotes: ".$this->rebotes;
    }
}
?>