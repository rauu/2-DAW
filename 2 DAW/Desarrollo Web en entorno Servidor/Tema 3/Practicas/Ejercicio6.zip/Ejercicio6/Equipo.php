<?php
require_once('AlaPivot.php');
require_once('Alero.php');
require_once('Base.php');
require_once('Equipo.php');
require_once('Escolta.php');
require_once('Jugador.php');
require_once('Pivot.php');

class Equipo
{
    private $nombre;
    private $AlaPivot = 0;
    private $Alero = 0;
    private $Base = 0;
    private $Pivot = 0;
    private $Escolta = 0;


    private $jugador = array();

    public function __construct($nombre, $jugador)
    {
        $this->nombre = $nombre;


        foreach ($jugador as $person) {
            if ($person instanceof AlaPivot) {
                $this->AlaPivot++;
            } else if ($person instanceof Alero) {
                $this->Alero++;
            } else if ($person instanceof Base) {
                $this->Base++;
            } else if ($person instanceof Escolta) {
                $this->Escolta++;
            } else if ($person instanceof Pivot) {
                $this->Pivot++;
            }
        }


        if ($this->AlaPivot == 1 && $this->Alero == 1 && $this->Base == 1 && $this->Escolta == 1 && $this->Pivot == 1) {
            foreach ($jugador as $player) {
                array_push($this->jugador, $player);
            }
        } else {
            echo ("No has metido todos los datos");
        }
    }


    public function __get($name)
    {
        switch ($name) {
            case 'nombre':
                return $this->nombre;
            case 'jugador':
                return $this->jugador;
        }
    }


    public function estaturaMedia($jugador)
    {
        //var_dump($jugador);
        $height = 0;
        $person = count($jugador);
        foreach ($jugador as $x) {
            $height = $height + $x->estatura;
        }

        $avg_height = $height / $person;

        return $avg_height;
    }

    public function estaturaMaxima($jugador){
        $height = 0;
        foreach ($jugador as $x) {
            if($height < $x->estatura){
                $height =$x->estatura;
            }
        }
        return $height;
    }

}
