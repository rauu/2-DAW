<?php
require_once ('Jugador.php');
class Alero extends Jugador
{
    private $robos;


    public function __construct($row)
    {
        parent::__construct($row);
        $this->robos = $row['robos'];
    }


    public function __get($name)
    {
        switch ($name) {
            case 'robos':
                return $this->robos;
            default:
                return parent::__get($name);
        }
    }

    public function __set($name, $value)
    {
        switch ($name) {
            case 'robos':
                $this->robos = $value;
                break;
        }
    }

    public function __toString(){
        return "Alero: ".$this->robos;
    }
}
?>