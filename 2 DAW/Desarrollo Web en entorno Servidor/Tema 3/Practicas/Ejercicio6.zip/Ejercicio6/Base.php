<?php
require_once ('Jugador.php');

class Base extends Jugador
{
    private $asistencias;


    public function __construct($row)
    {
        parent::__construct($row);
        $this->asistencias = $row['asistencias'];
    }


    public function __get($name)
    {
        switch ($name) {
            case 'asistencias':
                return $this->asistencias;
            default:
                return parent::__get($name);
        }
    }

    public function __set($name, $value)
    {
        switch ($name) {
            case 'asistencias':
                $this->asistencias = $value;
                break;
        }
    }
    public function __toString(){
        return "Asistencias: ".$this->asistencias;
    }
}
?>