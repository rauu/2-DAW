<?php
require_once ('Jugador.php');

class AlaPivot extends Jugador
{
    private $tapones;


    public function __construct($row)
    {
        parent::__construct($row);
        $this->tapones = $row['tapones'];
    }


    public function __get($name)
    {
        switch ($name) {
            case 'tapones':
                return $this->tapones;
            default:
                return parent::__get($name);
        }
    }

    public function __set($name, $value)
    {
        switch ($name) {
            case 'tapones':
                $this->tapones = $value;
                break;
        }
    }
    public function __toString(){
        return "Tapones: ".$this->tapones;
    }
}
?>