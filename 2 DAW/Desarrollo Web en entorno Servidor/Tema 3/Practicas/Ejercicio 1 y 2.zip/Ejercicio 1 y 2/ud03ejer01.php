
<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Ejercicio 1</title>
</head>
<body>
    <?php 

        include('contacto.php');
        $contacto1 = new Contacto("1234567T","Raunak","987654321");
        $contacto2 = new Contacto("1234567D","Angel","12345794");
        $contacto3 = new Contacto("1234567U","Victor","876541236");

        echo $contacto1->__toString()."<br>";
        echo $contacto2->__toString()."<br>";
        echo $contacto3->__toString()."<br>";
        
        

    ?>
</body>
</html>