
<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Ejercicio 1</title>
</head>
<body>
    <?php 

        include('contacto.php');
        include('agenda.php');
        
        
        $contact1 = new Contacto("001", "Raunak", "987654321");
        $contact2 = new Contacto("002", "Victor", "123456779");
        $contact3 = new Contacto("003", "Lucia", "234567844");
       
        $agenda = new Agenda();

        $agenda->anyadir($contact1);
        $agenda->anyadir($contact2);
        $agenda->anyadir($contact3);
        
        
    ?>
    <table border>

        <?php
           echo $agenda;
        ?>
    
    </table>
    <br><br>
    <table border> 
        <?php
          echo "<strong>Borro el usuario con el Id: 001<strong>";
          $agenda->eliminar("001");
          echo $agenda;
        ?>
    </table>
</body>
</html>