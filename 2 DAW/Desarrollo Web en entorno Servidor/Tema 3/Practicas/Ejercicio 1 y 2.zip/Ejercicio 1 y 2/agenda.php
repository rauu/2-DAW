<?php

    class Agenda{

        private $arrayContacto = [];

        
        
        public function anyadir($contacto){
            $this->arrayContacto[$contacto->getId()] = $contacto;
        }

        public function eliminar($id){
            unset($this->arrayContacto[$id]);
            
        }


        public function __toString()
        {
            $text =" ";
            $text .= "<tr>";
            $text .=  "<th>Id</th>";
            $text .=  "<th>Nombre</th>";
            $text .=  "<th>Telefono</th>";
            $text .=  "</tr>";

            foreach ($this->arrayContacto as $value) {
                $text .=  "<tr>";
                $text .=  "<td>".$value->getId()."</td>";
                $text .=  "<td>".$value->getName()."</td>";
                $text .=  "<td>".$value->getTelefono()."</td>";
                $text .=  "</tr>";
            }
            
            return $text;
        }

    }

?>