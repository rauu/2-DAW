<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Mostrar datos</title>
</head>
<body>
    <?php

        $nombre = $_GET['nombre'];
        $curso = $_GET['curso'];
        $genero = $_GET['genero'];

        echo "Nombre: ".$nombre."<br>";
        echo "Curso: ".$curso."<br>";
        echo "Genero: ".$genero;

    ?>
</body>
</html>