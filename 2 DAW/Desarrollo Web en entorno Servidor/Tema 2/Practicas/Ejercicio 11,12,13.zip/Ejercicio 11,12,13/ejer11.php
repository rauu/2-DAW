<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Ejercicio 11</title>
</head>
<body>
    <form action="mostrar.php" method="get">
    
    <h1>Formulario</h1>
    
    <label for="nombre">Nombre: </label>
    <input type="text" name="nombre" id="nombre"><br>
    <label for="curso">Curso: </label>
    <select name="curso" id="curso">
        <option value="1ºDAW">1ºDAW</option>
        <option value="2ºDAW">2ºDAW</option>
        <option value="2ºDAM">2ºDAM</option>
    </select><br>
    <label for="genero">Genero: </label>
    <input type="radio" name="genero" id="genero" value="male">Male
    <input type="radio" name="genero" id="genero" value="Female">Female <br>
    <input type="submit" value="Enviar datos" name="enviar">
   <!-- <?php/*

        if(isset($_GET['enviar']))
            echo "Se ha pulsado el botón de enviar";*/
    ?>-->

    
    </form>
    <style>
        form{
            padding:10px;
        }
        
    </style>
</body>
</html>