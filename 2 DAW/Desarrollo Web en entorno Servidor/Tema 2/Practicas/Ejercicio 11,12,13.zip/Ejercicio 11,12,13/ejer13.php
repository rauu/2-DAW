<!DOCTYPE html>
<html lang="es">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Ejercicio 13</title>
</head>

<body>

    <?php

    if (!empty($_POST['nombre'])  && !empty($_POST['music'])) {
        $nombre = $_POST['nombre'];
        $music = $_POST['music'];

        function getIPCliente()
        {
            if (isset($_SERVER['HTTP_CLIENT_IP'])) $ip = $_SERVER['HTTP_CLIENT_IP'];
            elseif (isset($_SERVER['HTTP_X_FORWARDED_FOR'])) $ip = $_SERVER['HTTP_X_FORWARDED_FOR'];
            elseif (isset($_SERVER['HTTP_X_FORWARDED'])) $ip = $_SERVER['HTTP_X_FORWARDED'];
            elseif (isset($_SERVER['HTTP_FORWARDED_FOR'])) $ip = $_SERVER['HTTP_FORWARDED_FOR'];
            elseif (isset($_SERVER['HTTP_FORWARDED'])) $ip = $_SERVER['HTTP_FORWARDED'];
            elseif (isset($_SERVER['REMOTE_ADDR'])) $ip = $_SERVER['REMOTE_ADDR'];
            else
                $ip = 'Origen desconocido.';
            return $ip;
        }

        function dias(){
            $weak = date('w');
    
            switch($weak){
                case 0:
                    $weak = "Domingo";
                break;
                case 1:
                    $weak = "Lunes";
                break;
                case 2:
                    $weak = "Martes";
                break;
                case 3:
                    $weak = "Miercoles";
                break;
                case 4:
                    $weak = "Jueves";
                break;
                case 5:
                    $weak = "Viernes";
                break;
                case 6:
                    $weak = "Sabado";
                break;
            }
            return $weak;
        }
    
        function meses(){
            $month = date('F');
    
            switch($month){
                case 0: 
                    $month = "Enero";
                break;
                case 1: 
                    $month = "Febrero";
                break;
                case 2: 
                    $month = "Marzo";
                break;
                case 3: 
                    $month = "Abril";
                break;
                case 4: 
                    $month = "Mayo";
                break;
                case 5: 
                    $month = "Junio";
                break;
                case 6: 
                    $month = "Julio";
                break;
                case 7: 
                    $month = "Agsoto";
                break;
                case 8: 
                    $month = "Septiembre";
                break;
                case 9: 
                    $month = "Octubre";
                break;
                case 10: 
                    $month = "Noviembre";
                break;
                case 11: 
                    $month = "Diciembre";
                break;
            }
            return $month;
        }
       
        //echo "hii";
        //echo dias();
        function fechaCastellano(){
            $de = " de ";
            $dia = date("d");
            $anyo = date('Y');
            $hora = date('H:i:s');
            echo dias().", ".$dia.$de.meses().$de.$anyo." ".$hora;
        }


        echo "Nombre: " . $nombre . "<br><br>";
        echo "Musica preferida<br>";
        foreach ($music as $x) {
            echo "- " . $x . " <br>";
        }
        echo "<br><br>";
        echo "IP de la maquina cliente: " . getIPCliente() . "<br><br>";
        echo "El nombre de la maquina es: " . gethostbyaddr(getIPCliente());

        echo "<br><br>";
        echo fechaCastellano();

        echo "<br><br>";
        
    ?>
    <button><a href="ejer13.php">Volver</a></button>
    <?php

    } else {


    ?>
    <form action="" method="post">

        <h1>Formulario</h1>

        <label for="nombre">Nombre: </label>
        <input type="text" name="nombre" id="nombre">

        <?php
            if (isset($_POST['enviar']) && empty($_POST['nombre']))
                echo "<span style='color:red'> ¡Debes introducir un nombre!!</span>";
            ?>

        <br><br>
        <label for="Musica">Musica: </label><br>
        <select multiple size="4" name="music[]" id="music">
            <option value="Acústica">Acústica</option>
            <?php
                if (isset($_POST['music']) && in_array("Acústica", $_POST['music']))
                ?>
            <option value="BSO">BSO</option>
            <?php
            if (isset($_POST['music']) && in_array("BSO", $_POST['music']))
                ?>
            <option value="R&B">R&B</option>
            <?php
            if (isset($_POST['music']) && in_array("R&B", $_POST['music']))
                ?>
            <option value="Electrónica">Electrónica</option>
            <?php
            if (isset($_POST['music']) && in_array("Electrónica", $_POST['music']))
                ?>
            <option value="Folk">Folk</option>
            <?php
            if (isset($_POST['music']) && in_array("Folk", $_POST['music']))
                ?>
            <option value="Jazz">Jazz</option>
            <?php
            if (isset($_POST['music']) && in_array("Jazz", $_POST['music']))
                ?>
            <option value="Pop">Pop</option>
            <?php
            if (isset($_POST['music']) && in_array("Pop", $_POST['music']))
                ?>
            <option value="Rock">Rock</option>
            <?php
            if (isset($_POST['music']) && in_array("Rock", $_POST['music']))
                ?>

        </select>
        <?php
        if (isset($_POST['enviar']) && empty($_POST['respuesta']))
            echo "<span style='color:red'>¡Debes escoger al menos uno!!</span>"
            ?>

        <br><br>

        <input type="submit" value="Enviar" name="enviar">

    </form>

    <?php
    }
        ?>




    <style>
    form {
        padding: 10px;
    }

    a {
        text-decoration: none;
        color: black;
    }
    </style>
</body>

</html>