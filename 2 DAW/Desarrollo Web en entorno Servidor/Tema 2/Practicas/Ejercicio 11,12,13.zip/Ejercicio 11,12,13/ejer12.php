<!DOCTYPE html>
<html lang="es">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Ejercicio 12</title>
</head>

<body>

    <?php

        if (!empty($_POST['nombre'])  && !empty($_POST['carta']) && !empty($_POST['respuesta'])) {
            $nombre = $_POST['nombre'];
            $carta = $_POST['carta'];
            $respuesta = $_POST['respuesta'];
            
            echo "Nombre: " . $nombre . "<br><br>";
            echo "Reyes a los que va dirigida<br>";
            
            foreach ($respuesta as $x){
                echo "- ".$x." <br>";
            }
            echo "<br>";
            echo "Carta: " . $carta  . "<br>";
        } else 
        {
        
    
    ?>




    <form action="" method="post">

        <h1>OTRO FORMUARIO INVENTADO</h1>

        <label for="nombre">Nombre: </label>
        <input type="text" name="nombre" id="nombre" value="<?php if(isset($_POST['nombre'])) echo $_POST['nombre'];?>">

        <?php
            if (isset($_POST['enviar']) && empty($_POST['nombre']))
            echo "<span style='color:red'> ¡Debes introducir un nombre!!</span>" 
        ?>

        <br><br>

        <label for="pregunta">¿A qué rey o reyes va dirigida?</label><br>
       

        <input type="checkbox" name="respuesta[]" value="Melchor"> Melchor <br>
        <?php
            if(isset($_POST['respuesta']) && in_array("Melchor",$_POST['respuesta']))
        ?>
        <input type="checkbox" name="respuesta[]" value="Gaspar"> Gaspar <br>
        <?php
            if(isset($_POST['respuesta']) && in_array("Gaspar",$_POST['respuesta']))
        ?>
        <input type="checkbox" name="respuesta[]" value="Baltasar"> Baltasar
        <?php
            if(isset($_POST['respuesta']) && in_array("Baltasar",$_POST['respuesta']))
            //echo 'checked="checked"';
        ?>
        <?php
            if (isset($_POST['enviar']) && empty($_POST['respuesta']))
            echo "<span style='color:red'>¡Debes escoger al menos uno!!</span>"
        ?>

        <br><br>

        <label for="carta">Escribe tu carta para los Reyes Magos</label><br>
        
        <textarea name="carta" id="" cols="35" rows="5"></textarea>
        <?php
            if (isset($_POST['enviar']) && empty($_POST['carta']))
            echo "<span style='color:red'>¡Debes escribir algo!</span>"
        ?>
        <br><br>
        <input type="submit" value="Enviar" name="enviar">



    </form>
    <?php 
        } 
    ?>
</body>

</html>