<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Ejercicio 1</title>
</head>

<body>
    <?php

    //conexion BBDD
    $conexion = new mysqli('localhost', 'root', '', 'bdlibros');



    //CREO UNA MALA CONEXION PARA VER SI QUE ME SACA ERROR

    //SI, SALE ERROR


    /*$conexio2 = new mysqli('localhost', 'rauu', '', 'bdlibros');
    if ($conexio2->connect_errno) {
        die('Lo siento, hubo un problema con la base de datos');
    }else{
        echo "Funca";
    }*/



    if ($conexion->connect_errno) {
        die('Lo siento, hubo un problema con la base de datos');
    } else {
        $insert1 = $conexion->query("INSERT INTO libros(id, titulo,autor, paginas)
            VALUES (1, 'JarryChopedy la Hierba Filosofal', 'JK Blowling', 301)");
        $insert2 = $conexion->query("INSERT INTO libros(id, titulo,autor, paginas)
            VALUES (2, 'El Senyorde los Palillos', 'JRR TolQuien', 550)");
        $insert3 = $conexion->query("INSERT INTO libros(id, titulo,autor, paginas)
            VALUES (3, 'JarryChopedy la Sabana Secreta', 'JK Blowling', 302)");
        $insert4 = $conexion->query("INSERT INTO libros(id, titulo,autor, paginas)
            VALUES (4, 'Los Polares de la Tierra', 'JK Blowling', 400)");
        $insert5 = $conexion->query("INSERT INTO libros(id, titulo,autor, paginas)
            VALUES (5, 'JarryChopedy el peluquero de Azkaban', 'Ken Follonet', 303)");
        $insert6 = $conexion->query("INSERT INTO libros(id, titulo,autor, paginas)
            VALUES (6, 'Los Juegos de Enjambre', 'Suzanne Collonins', 450)");
        $insert7 = $conexion->query("INSERT INTO libros(id, titulo,autor, paginas)
            VALUES (7, 'JarryChopedy el lapizde fuego', 'JK Blowling', 304)");
        $insert8 = $conexion->query("INSERT INTO libros(id, titulo,autor, paginas)
            VALUES (8, 'El Bolidoda Vinci', 'Dan Black', 500)");



        //Tabla de 8 libros sin orden 
    ?>
    <table border>
        <tr>
            <th>id</th>
            <th>titulo</th>
            <th>autor</th>
            <th>paginas</th>
        </tr>
        <tr>

            <?php
                echo "Introducimos 8 libros en la tabla y mostramos...";
                $consultado = $conexion->query("SELECT * FROM libros");
                $resultado = $consultado->fetch_assoc();
                while ($resultado != null) {
                    echo "<tr>";
                    echo "<td>" . $resultado['id'] . "</td> <td>" . $resultado['titulo'] . "</td> <td>" . $resultado['autor'] . "</td> <td>" . $resultado['paginas'] . "</td>";
                    $resultado = $consultado->fetch_assoc();
                    echo "</tr>";
                } ?>
        </tr>
    </table>

    <br>
    <br>
    <br>
    <br>
    <br>

    <!-- la misma tabla pero con el orden de paginas desendente-->
    <table border>
        <tr>
            <th>id</th>
            <th>titulo</th>
            <th>autor</th>
            <th>paginas</th>
        </tr>
        <tr>

            <?php
                echo "Mostramos 8 libros ordenados por numero de paginas decendente";
                $consultado1 = $conexion->query("SELECT * FROM libros ORDER BY paginas DESC");
                $resultado = $consultado1->fetch_assoc();
                while ($resultado != null) {
                    echo "<tr>";
                    echo "<td>" . $resultado['id'] . "</td> <td>" . $resultado['titulo'] . "</td> <td>" . $resultado['autor'] . "</td> <td>" . $resultado['paginas'] . "</td>";
                    $resultado = $consultado1->fetch_assoc();
                    echo "</tr>";
                } ?>
        </tr>
    </table>
    <br>
    <br>
    <br>
    <br>
    <br>

    <!-- Mostrar solo titulo y paginas de los libros de JK Blowling-->
    <table border>
        <tr>

            <th>titulo</th>

            <th>paginas</th>
        </tr>
        <tr>

            <?php
                echo "Mostramos solo titulo y pagina de los libros de JK Bowling";
                $consultado2 = $conexion->query("SELECT titulo, paginas FROM libros WHERE autor = 'JK Blowling'");
                $resultado = $consultado2->fetch_assoc();
                while ($resultado != null) {
                    echo "<tr>";
                    echo "<td>" . $resultado['titulo'] . "</td> <td>" . $resultado['paginas'] . "</td>";
                    $resultado = $consultado2->fetch_assoc();
                    echo "</tr>";
                }




                ?>
        </tr>
    </table>

    <br>
    <br>
    <br>
    <br>
    <br>

    <!-- Eliminar los libros de JK Blowling-->
    <table border>
        <tr>

            <th>id</th>
            <th>titulo</th>
            <th>autor</th>
            <th>paginas</th>
        </tr>


        <?php
        
        $consultado_delete = $conexion->query("DELETE FROM libros WHERE autor = 'JK Blowling'");
        $consultado3 = $conexion->query("SELECT * FROM libros");
        echo "Eliminamos los libros de JK Blowling (".$conexion->affected_rows." filas eliminadas), y mostramos todo";
        $resultado = $consultado3->fetch_assoc();
        while ($resultado != null) {
            echo "<tr>";

            echo "<td>" . $resultado['id'] . "</td> <td>" . $resultado['titulo'] . "</td> <td>" . $resultado['autor'] . "</td> <td>" . $resultado['paginas'] . "</td>";
            $resultado = $consultado3->fetch_assoc();
            echo "</tr>";
        }
    



        ?>
    

    </table>
    <br>
    <br>
    <br>
    <br>
    <br>

    <!-- Modificmos el titulo del 8 y mostramos todo-->
    <table border>
        <tr>

            <th>id</th>
            <th>titulo</th>
            <th>autor</th>
            <th>paginas</th>
        </tr>


        <?php
        
       $consultado_update = $conexion->query("UPDATE libros SET titulo = 'El Morbido da Vinci' WHERE id = 8");
        $consultado4 = $conexion->query("SELECT * FROM libros");
        echo "Modificmos el titulo del 8 y mostramos todo: ";
        $resultado = $consultado4->fetch_assoc();
        while ($resultado != null) {
            echo "<tr>";

            echo "<td>" . $resultado['id'] . "</td> <td>" . $resultado['titulo'] . "</td> <td>" . $resultado['autor'] . "</td> <td>" . $resultado['paginas'] . "</td>";
            $resultado = $consultado4->fetch_assoc();
            echo "</tr>";
        }
    }

    $conexion->close();

        ?>

    </table>


</body>

</html>