<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Ejercicio 2</title>
</head>

<body>

    <form action=" " method="post">

        <label for="id">Id: </label>
        <input type="text" name="id" id="id" value="<?php if (isset($_POST['id'])) echo $_POST['id']; ?>">

        <?php
        if (isset($_POST['enviar']) && empty($_POST['id']))
            echo "<span style='color:red'>&#8592; ¡Debes introducir un Id!!</span>"
        ?>

        <br><br>


        <label for="titulo">Titulo: </label>
        <input type="text" name="titulo" id="titulo" value="<?php if (isset($_POST['titulo'])) echo $_POST['titulo']; ?>">

        <?php
        if (isset($_POST['enviar']) && empty($_POST['titulo']))
            echo "<span style='color:red'>&#8592; ¡Debes introducir un Titulo!!</span>"
        ?>

        <br><br>


        <label for="autor">Autor: </label>
        <input type="text" name="autor" id="autor" value="<?php if (isset($_POST['autor'])) echo $_POST['autor']; ?>">

        <?php
        if (isset($_POST['enviar']) && empty($_POST['autor']))
            echo "<span style='color:red'>&#8592; ¡Debes introducir un Autor!!</span>"
        ?>

        <br><br>


        <label for="paginas">Paginas: </label>
        <input type="text" name="paginas" id="paginas" value="<?php if (isset($_POST['paginas'])) echo $_POST['paginas']; ?>">

        <?php
        if (isset($_POST['enviar']) && empty($_POST['paginas']))
            echo "<span style='color:red'>&#8592; ¡Debes introducir un Paginas!!</span>"
        ?>

        <br><br>


        <button type="submit" name="enviar">Introducir libro</button>


    </form>

    <br><br><br>

    <?php
    $conexion = new mysqli('localhost', 'root', '', 'bdlibros');
    if (!empty($_POST['id']) && !empty($_POST['titulo']) && !empty($_POST['autor']) && !empty($_POST['paginas'])) {
        $id = $_POST['id'];
        $titulo = $_POST['titulo'];
        $autor = $_POST['autor'];
        $paginas = $_POST['paginas'];

        $conexion = new mysqli('localhost', 'root', '', 'bdlibros');
        if ($conexion->connect_errno) {
            die('Lo siento, hubo un problema con la base de datos');
        } else {
            $insert = $conexion->query("INSERT INTO libros(id, titulo,autor, paginas)
            VALUES ($id, '$titulo', '$autor', $paginas)");
            header('Location: ./ud04ejer02.php');
        }
    }
    ?>

    <table border>

        <tr>
            <th>ID</th>
            <th>Titulo</th>
            <th>AUTHOR</th>
            <th>PAGINAS</th>
        </tr>
        <?php
        $consultado = $conexion->query("SELECT * FROM libros");
        $resultado = $consultado->fetch_assoc();
        while ($resultado != null) {
            echo "<tr>";
            echo "<td>" . $resultado['id'] . "</td> <td>" . $resultado['titulo'] . "</td> <td>" . $resultado['autor'] . "</td> <td>" . $resultado['paginas'] . "</td>";
            $resultado = $consultado->fetch_assoc();
            echo "</tr>";
        }

        ?>
    </table>

    <?php
    $conexion->close();
    ?>
</body>

</html>