<nav>
	<ul>
		<li><a href="index.php">Inicio</a></li>
		<li><a href="index.php?action=nosotros">Nosotros</a></li>
		<li><a href="index.php?action=servicios">Servicios</a></li>
		<li><a href="index.php?action=contactenos">Contáctenos</a></li>
		<li><a href="index.php?action=ofertas">Ofertas</a></li>
		<li><a href="index.php?action=novedades">Novedades</a></li>
	</ul>
</nav>