<?php

class Config 
{ 
	static public $mvc_bd_hostname = "localhost"; 
	static public $mvc_bd_nombre = "bdalimentos"; 
	static public $mvc_bd_usuario = "root"; 
	static public $mvc_bd_clave = "root"; 
	static public $mvc_css = "estilo.css"; 
}
