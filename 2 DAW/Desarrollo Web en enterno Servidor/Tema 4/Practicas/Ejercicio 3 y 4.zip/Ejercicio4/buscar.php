<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Budcar Libro</title>
</head>
<body>
    
<h1>Libros Encontrados</h1>
<table border>

    <tr>
        <th>ID</th>
        <th>Titulo</th>
        <th>AUTHOR</th>
        <th>PAGINAS</th>
        <th>MODIFICAR</th>
        <th>ELIMINAR</th>

    </tr>

    <?php

    $buscar = $_POST['buscar'];
    

    function getConexion()
    {
        $host = "localhost";
        $db = "bdlibros";
        $user = "root";
        $pass = "";
        $conexion = new PDO("mysql:host=$host;dbname=$db;", $user, $pass);
        return $conexion;
    }
    function buscarTitilos($buscar)
    {
        $conexion = getConexion();
        $sql = "SELECT * FROM libros WHERE titulo LIKE '%$buscar%'";
        $resultado = $conexion->prepare($sql);
        $resultado->bindParam(':titulo', $buscar);
        $resultado->execute();
        $rows = null;

        while ($fila = $resultado->fetch()) {
            // guardamos las filas en un array
            $rows = $rows . "<tr><td>" . $fila['id'] . "</td> <td>" . $fila['titulo'] . "</td> <td>" . $fila['autor'] . "</td> 
             <td>" . $fila['paginas'] . "</td> <td><a href = \"./modificar.php?id=" . $fila['id'] . "&titulo=" . $fila['titulo'] . "&autor=" . $fila['autor'] . "&paginas=" . $fila['paginas'] . "\">Modificar</a></td> <td>
             <a href = \"./eliminar.php?id=" . $fila['id'] . "\">Eliminar</a></td></tr>";
        }
        
        return $rows;

    }

    echo buscarTitilos($buscar);
    ?>

</table>

<br><br>

<a href="ud04ejer04.php">Volver a la pagina principal</a>
</body>
</html>
