<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Ejercicio 4 - PDO</title>
</head>

<body>


    <form action="buscar.php" method="POST">
        <input type="text" name="buscar" id="buscar" size="30">
        
        <button type="submit" name="buscar_enviar">BUSCAR</button>
        <?php
        if (isset($_POST['buscar_enviar']) && empty($_POST['buscar']))
            echo "<span style='color:red'>&#8592; ¡Debes escribir un libro!!</span>";

            if (!empty($_POST['buscar']) ) {

               
                
            }
        ?>
    </form>
    <br>
    <br>
    <br>
    <br>
    <form action=" " method="post">

        <label for="id">Id: </label>
        <input type="text" name="id" id="id" value="<?php if (isset($_POST['id'])) echo $_POST['id']; ?>">

        <?php
        if (isset($_POST['enviar']) && empty($_POST['id']))
            echo "<span style='color:red'>&#8592; ¡Debes introducir un Id!!</span>";
        ?>

        <br><br>


        <label for="titulo">Titulo: </label>
        <input type="text" name="titulo" id="titulo" value="<?php if (isset($_POST['titulo'])) echo $_POST['titulo']; ?>">

        <?php
        if (isset($_POST['enviar']) && empty($_POST['titulo']))
            echo "<span style='color:red'>&#8592; ¡Debes introducir un Titulo!!</span>";
        ?>

        <br><br>


        <label for="autor">Autor: </label>
        <input type="text" name="autor" id="autor" value="<?php if (isset($_POST['autor'])) echo $_POST['autor']; ?>">

        <?php
        if (isset($_POST['enviar']) && empty($_POST['autor']))
            echo "<span style='color:red'>&#8592; ¡Debes introducir un Autor!!</span>";
        ?>

        <br><br>


        <label for="paginas">Paginas: </label>
        <input type="text" name="paginas" id="paginas" value="<?php if (isset($_POST['paginas'])) echo $_POST['paginas']; ?>">

        <?php
        if (isset($_POST['enviar']) && empty($_POST['paginas']))
            echo "<span style='color:red'>&#8592; ¡Debes introducir un Paginas!!</span>";
        ?>

        <br><br>


        <button type="submit" name="enviar">Introducir libro</button>


    </form>

    <br><br><br>

    <?php
    // La conexion a la BBDD
    function getConexion()
    {
        $host = "localhost";
        $db = "bdlibros";
        $user = "root";
        $pass = "";
        $conexion = new PDO("mysql:host=$host;dbname=$db;", $user, $pass);
        return $conexion;
    }

    //Function para insert libros
    function insertarProduct($id, $titulo, $autor, $paginas)
    {

        $conexion = getConexion();

        $sql = "INSERT INTO libros (id, titulo, autor, paginas) 
                VALUES (:id, :titulo, :autor, :paginas)";

        $resultado = $conexion->prepare($sql);
        $resultado->bindParam(':id', $id);
        $resultado->bindParam(':titulo', $titulo);
        $resultado->bindParam(':autor', $autor);
        $resultado->bindParam(':paginas', $paginas);



        if (!$resultado) {
            $mensaje = "Error al crear el registro";
        } else {
            $resultado->execute();

            $mensaje = "Registro creado correctamente";
        }
        //echo $mensaje;
        return $mensaje;
    }

    //If en el caso que de que si todos los campos tiene algun valor pues que me inserte datos
    if (!empty($_POST['id']) && !empty($_POST['titulo']) && !empty($_POST['autor']) && !empty($_POST['paginas'])) {

        //header('Location: ./ud04ejer04.php');
        echo insertarProduct($_POST['id'], $_POST['titulo'], $_POST['autor'], $_POST['paginas']);
    }


    ?>

    <table border>

        <tr>
            <th>ID</th>
            <th>Titulo</th>
            <th>AUTHOR</th>
            <th>PAGINAS</th>
            <th>MODIFICAR</th>
            <th>ELIMINAR</th>

        </tr>
        <?php
        function select()
        {
            $conexion = getConexion();

            $sql = "SELECT * FROM libros";
            $resultado = $conexion->prepare($sql);
            $resultado->execute();
            $rows = null;
            while ($fila = $resultado->fetch()) {
                // guardamos las filas en un array
                $rows = $rows . "<tr><td>" . $fila['id'] . "</td> <td>" . $fila['titulo'] . "</td> <td>" . $fila['autor'] . "</td> 
                 <td>" . $fila['paginas'] . "</td> <td><a href = \"./modificar.php?id=" . $fila['id'] . "&titulo=" . $fila['titulo'] . "&autor=" . $fila['autor'] . "&paginas=" . $fila['paginas'] . "\">Modificar</a></td> <td>
                 <a href = \"./eliminar.php?id=" . $fila['id'] . "\">Eliminar</a></td></tr>";
            }
            return $rows;
        }
        echo select();
        ?>


    </table>

    <?php



    //$conexion->close();
    ?>
    <style>
        form{
            justify-content: center;
        }
        button {
            height: 3em;
            width: 7em;
            background-color: #c5c7c5;
        }
        #buscar{
            height: 2.5em;
        }
    </style>
</body>

</html>