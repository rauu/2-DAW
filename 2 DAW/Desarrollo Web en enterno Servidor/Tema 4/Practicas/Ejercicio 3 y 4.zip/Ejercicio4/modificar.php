<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Modificar productos</title>
</head>

<body>
    <h1>Modificar Productos</h1>

    <?php
    //Recoger valores de POST
    $id = $_GET['id'];
    $titulo = $_GET['titulo'];
    $autor = $_GET['autor'];
    $paginas = $_GET['paginas'];


    ?>

    <form action="" method="post">

        <label for="id">Id: </label>
        <input type="text" name="id" id="id" readonly="readonly" value="<?php if (isset($_POST['id'])) echo $_POST['id'];
                                                                        else {
                                                                            echo $id;
                                                                        } ?>">

        <?php
        if (isset($_POST['enviar']) && empty($_POST['id']))
            echo "<span style='color:red'>&#8592; ¡Debes introducir un Id!!</span>";
        ?>

        <br><br>


        <label for="titulo">Titulo: </label>
        <input type="text" name="titulo" id="titulo" value="<?php if (isset($_POST['titulo'])) echo $_POST['titulo'];
                                                            else echo $titulo ?>">

        <?php
        if (isset($_POST['enviar']) && empty($_POST['titulo']))
            echo "<span style='color:red'>&#8592; ¡Debes introducir un Titulo!!</span>";
        ?>

        <br><br>


        <label for="autor">Autor: </label>
        <input type="text" name="autor" id="autor" value="<?php
                                                            if (isset($_POST['autor'])) echo $_POST['autor'];
                                                            else echo $autor; ?>">

        <?php
        if (isset($_POST['enviar']) && empty($_POST['autor']))
            echo "<span style='color:red'>&#8592; ¡Debes introducir un Autor!!</span>";
        ?>

        <br><br>


        <label for="paginas">Paginas: </label>
        <input type="text" name="paginas" id="paginas" value="<?php
                                                                if (isset($_POST['paginas'])) echo $_POST['paginas'];
                                                                else echo $paginas ?>">

        <?php
        if (isset($_POST['enviar']) && empty($_POST['paginas']))
            echo "<span style='color:red'>&#8592; ¡Debes introducir un Paginas!!</span>";
        ?>

        <br><br>


        <button type="submit" name="enviar">Modificar Productos</button>


    </form>

    <br>
    <br>
    <?php
    function getConexion()
    {
        $host = "localhost";
        $db = "bdlibros";
        $user = "root";
        $pass = "";
        $conexion = new PDO("mysql:host=$host;dbname=$db;", $user, $pass);
        return $conexion;
    }
    function modificarDatos($id, $titulo, $autor, $paginas)
    {

        $conexion = getConexion();
        $sql = "UPDATE libros
                SET titulo = :titulo, autor = :autor, paginas = :paginas
                WHERE id = :id";

        $resultado = $conexion->prepare($sql);
        $resultado->bindParam(':id', $id);
        $resultado->bindParam(':titulo', $titulo);
        $resultado->bindParam(':autor', $autor);
        $resultado->bindParam(':paginas', $paginas);



        if (!$resultado) {
            $mensaje = "Error al modificar el registro";
        } else {
            $resultado->execute();

            $mensaje = "Registro modificado correctamente";
        }
        //echo $mensaje;
        return $mensaje;
    }

    //If en el caso que de que si todos los campos tiene algun valor pues que se modifique datos
    if (!empty($_POST['id']) && !empty($_POST['titulo']) && !empty($_POST['autor']) && !empty($_POST['paginas'])) {

        //header('Location: ./ud04ejer04.php');
        //echo modificarDatos($id, $titulo, $autor, $paginas);
        echo modificarDatos($_POST['id'], $_POST['titulo'], $_POST['autor'], $_POST['paginas']);
    }


    ?>

    <br>
    <br>
    <a href="./ud04ejer04.php">Volver a la pagina principal</a>


</body>

</html>