<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Nuevos articulos</title>
</head>
<body>
    <h1>Dar de alta ARTICÚLOS NUEVOS</h1>

    <form action="resultario.php" method="GET">

        <label for="seccion">Sección del Articulo: </label>
        <input type="text" name="seccion" id="seccion"><br><br>
        <label for="articulo">Nombre del Articulo: </label>
        <input type="text" name="articulo" id="articulo"><br><br>
        <label for="precio">Precio del Articulo: </label>
        <input type="text" name="precio" id="precio"><br><br>
        <label for="paisorigen">Pais Origen Articulo: </label>
        <input type="text" name="paisorigen" id="paisorigen"><br><br>
        <button type="submit">¡¡INSERTAR!!</button>

    </form>

    <h1>Buscar Articulos</h1>
    <button type="button"><a href="formulariobusqueda.php">BUSCAR</a></button>
</body>
</html>