<!doctype html>
<html lang="en">

<head>
    <meta charset="utf-8">
    <title>Paises</title>
</head>

<body>
    <form action="resultadopaises.php" method="get">
        <label>Escribe el pais: <input type="text" name="pais" />
        </label><input type="submit" name="enviando" value="BUSCAR" />
    </form>
</body>

</html>