<?php
$db_host = "localhost";
$db_usuario = "root";
$db_contrasena = "";
$db_nombre = "bdproductos";
