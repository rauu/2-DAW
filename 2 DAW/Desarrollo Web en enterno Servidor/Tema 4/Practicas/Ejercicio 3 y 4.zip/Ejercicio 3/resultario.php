<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Resultari</title>
</head>

<body>
    <?php
    require('dataconexion.php');


    //Recoger los datos de GET
    $seccion = $_GET['seccion'];
    $articulo = $_GET['articulo'];
    $precio = $_GET['precio'];
    $paisorigen = $_GET['paisorigen'];


    //Conectar a  BBDD
    //echo $db_host, $db_usuario, $db_contrasena, $db_nombre;
    $conexion = mysqli_connect($db_host, $db_usuario, $db_contrasena, $db_nombre);
    //var_dump($conexion);
    if (mysqli_connect_errno()) {
        echo "Houston, tenemos un problema...";
        exit();
    } // seleccionamos la conexión y la base de datos (si verdadero, ya no muere)
    //mysqli_select_db($conexion, $db_nombre) or die("NO encuentro la base de datos.");
    // para admitir ñ y tildes (conjunto de caracteres para envíos desde y hacia el servidor de la BD).
    mysqli_set_charset($conexion, "utf8");
    // creamos la sentencia SQL para insertar

    $consulta = $conexion->prepare("INSERT INTO productos (seccion, articulo, precio, paisorigen)
                                    VALUES (?, ?, ?, ?)");
    $consulta->bind_param('ssis', $seccion, $articulo, $precio, $paisorigen);

    $ok = mysqli_stmt_execute($consulta);
    if ($ok) {
        echo "Articulo insertado: " . $articulo . "<br><br>";

        echo "<a href=\"formulariointroduccion.php\">Insertar un Articulo NUEVO</a>";
    } else {
        echo "Error al ejecutar la consulta";
    }


    mysqli_close($conexion);
    ?>
</body>

</html>