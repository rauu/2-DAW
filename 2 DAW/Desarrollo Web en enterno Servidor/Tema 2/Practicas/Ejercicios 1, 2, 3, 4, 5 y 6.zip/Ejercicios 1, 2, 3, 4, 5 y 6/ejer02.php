<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Ejercicio2</title>
</head>
<body>
    <?php
        $num1 = 3;
        $num2 = 7.2;
        $num3 = 0x1C;

        $resultado = $num1 + $num2 + $num3;
        
        echo "El resultado es: ".$resultado;
    ?>
</body>
</html>