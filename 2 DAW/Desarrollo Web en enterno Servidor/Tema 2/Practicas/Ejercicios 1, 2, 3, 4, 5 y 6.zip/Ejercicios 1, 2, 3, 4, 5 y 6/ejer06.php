<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Ejercicio 6</title>
</head>
<body>
    <?php

        include 'funciones02.php';
        
        calcularPrecio(54);

        echo "</br>";

        calcularPrecio(100);

        echo "</br>";
        
        calcularPrecio(510);

        echo "</br>";

        

    ?>
</body>
</html>