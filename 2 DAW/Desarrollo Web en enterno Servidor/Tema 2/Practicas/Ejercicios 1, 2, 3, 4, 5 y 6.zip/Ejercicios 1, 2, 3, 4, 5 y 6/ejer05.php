<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Ejercicio 5</title>
</head>
<body>
    <?php

        echo "<h1>Tabla de Multiplicar</h1></br></br>";
        echo "La tabla de multiplicar del 7 es: </br></br>";
    

        function multiplicar($num){
            $result = 0;
            for($x = 1; $x <= 10; $x++){
                $result = $num * $x;
                echo $num." x ".$x." = ".$result."</br>";
            }
        }

        multiplicar(7);
        
        
        

    ?>
</body>
</html>