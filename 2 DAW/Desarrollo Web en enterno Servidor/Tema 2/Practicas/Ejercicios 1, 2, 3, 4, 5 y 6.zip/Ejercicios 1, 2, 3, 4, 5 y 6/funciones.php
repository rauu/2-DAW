<?php 

    function dias(){
        $weak = date('w');

        switch($weak){
            case 0:
                $weak = "Domingo";
            break;
            case 1:
                $weak = "Lunes";
            break;
            case 2:
                $weak = "Martes";
            break;
            case 3:
                $weak = "Miercoles";
            break;
            case 4:
                $weak = "Jueves";
            break;
            case 5:
                $weak = "Viernes";
            break;
            case 6:
                $weak = "Sabado";
            break;
        }
        return $weak;
    }

    function meses(){
        $month = date('F');

        switch($month){
            case 0: 
                $month = "Enero";
            break;
            case 1: 
                $month = "Febrero";
            break;
            case 2: 
                $month = "Marzo";
            break;
            case 3: 
                $month = "Abril";
            break;
            case 4: 
                $month = "Mayo";
            break;
            case 5: 
                $month = "Junio";
            break;
            case 6: 
                $month = "Julio";
            break;
            case 7: 
                $month = "Agsoto";
            break;
            case 8: 
                $month = "Septiembre";
            break;
            case 9: 
                $month = "Octubre";
            break;
            case 10: 
                $month = "Noviembre";
            break;
            case 11: 
                $month = "Diciembre";
            break;
        }
        return $month;
    }
   
    //echo "hii";
    //echo dias();

    function fechaCastellano(){
        $de = " de ";
        $dia = date("d");
        $anyo = date('Y');
        echo dias().", ".$dia.$de.meses().$de.$anyo;
    }






    

    function factor($num = 4){
        $factorial = 1;
       
        for($x = 1; $x<=$num;$x++){
            $factorial = $factorial * $x;
        }
        
        return $factorial;
    }


?>