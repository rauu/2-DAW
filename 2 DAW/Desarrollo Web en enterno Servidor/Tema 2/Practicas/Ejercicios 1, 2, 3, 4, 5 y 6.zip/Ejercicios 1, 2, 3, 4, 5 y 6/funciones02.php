<?php
    function calcularPrecio($precio)
    {
        $precioFinal = $precio;
        echo "Precio inicial: ".$precio."</br>";
        if ($precio < 100) {
            echo "No se aplica ningún descuento"."</br>";
            $precioFinal = $precio;
            echo "Precio Final: ".$precioFinal."</br>";
        } elseif ($precio >= 100 && $precio <= 500) {
            echo "Se aplica un descuento de 10%"."</br>";
            $precioFinal = $precio - ($precio * 0.1);
            echo "Precio Final: ".$precioFinal."</br>";
        } elseif ($precio > 500){
            echo "Se aplica un descuento de 15%"."</br>";
            $precioFinal = $precio - ($precio * 0.15);
            echo "Precio Final: ".$precioFinal."</br>";
        }
    }
