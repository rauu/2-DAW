<!DOCTYPE html>
<html lang="es">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Ejercicio 09</title>
</head>

<body>
    <table>
        <?php

        while (key($_SERVER) == true) {

            echo "<tr>";
            echo "<td>";
            echo key($_SERVER);
            echo "</td>";
            echo "<td>";
            echo current($_SERVER);
            echo "</td>";

            next($_SERVER);
            
        
            
            echo "</tr>";
        }



        ?>
    </table>
    <style>
    
    table,td{
        border: 1px solid black;
        padding: 10px;
    }


    </style>
</body>

</html>