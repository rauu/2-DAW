<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Ejercicio 07</title>
    <link rel="stylesheet" type="text/css" href="style.css">
</head>
<body>
    <table>
        <?php 
            foreach($_SERVER as $x => $c){
                echo "<tr>";
                echo "<td>" . $x . "</td>   ";
                echo "<td>" . $c . "</td> ";
                echo "</tr>";
            }
        ?>
    </table>
    <?php 
    echo "Pregunta 1: asociativo <br></br> Pregunta 2: Sí, utilizando array_keys(array) para obtener las llaves en un array y luego haces el for.";
    ?>

    <style>
    
    table,td{
        border: 1px solid black;
        padding: 10px;
    }


    </style>
</body>
</html>