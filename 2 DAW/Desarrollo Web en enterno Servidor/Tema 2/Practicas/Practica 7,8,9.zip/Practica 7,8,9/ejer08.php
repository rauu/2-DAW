<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Ejercicio 8</title>
</head>

<body>
    <?php

    $arrayA = array(array(1, 3, 0, 8), array(13, 5, 2), array(18, 4, 1, 9, 87), array(6, 9,));
    $size = 0;
    $index;
    $arrayB = [];
    foreach ($arrayA as $x) {
        if (count($x) > count($arrayB)) {
            $arrayB = $x;
            $index = array_search($arrayB, $arrayA);
        }
    }

    print_r($arrayA[$index]);

    ?>
</body>

</html>