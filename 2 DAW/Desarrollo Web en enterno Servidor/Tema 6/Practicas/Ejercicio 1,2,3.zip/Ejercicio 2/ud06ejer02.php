<?php
function miniatura($name_org, $name_dst, $ancho, $alto)
{
    // Separamos el nombre y la extensión en un array de 2 elementos
    $arrNombre = explode(".", $name_dst);
    $nombre = $arrNombre[0];
    $extension = $arrNombre[1];
    // Creamos una nueva imagen, para cada tipo de extensión posible
    if ($extension == "jpg" || $extension == "jpeg") {
        $source = imagecreatefromjpeg($name_org);
    } elseif ($extension == "png") {
        $source = imagecreatefrompng($name_org);
    } elseif ($extension == "gif") {
        $source = imagecreatefromgif($name_org);
    }
    // Creamos el thumbnail vacio
    $thumb = imagecreatetruecolor($ancho, $alto);
    $ancho_orig = imagesx($source);
    $alto_orig = imagesy($source);
    // Copiamos la imagen en un thumbnail pasándole los parámetros necesarios
    imagecopyresampled($thumb, $source, 0, 0, 0, 0, $ancho, $alto, $ancho_orig, $alto_orig); // Le añadimos la extensión
    $thumb_name = $nombre . "." . $extension;
    // Exportamos al formato elegido (Con el formato jpg o jpeg podemos elegir calidad).
    if ($extension == "jpg" || $extension == "jpeg") {
        imagejpeg($thumb, $thumb_name, 90);
    } elseif ($extension == "png") {
        imagepng($thumb, $thumb_name);
    } elseif ($extension == "gif") {
        imagegif($thumb, $thumb_name);
    }
}

if (isset($_POST['subir'])) {
    if ($_FILES['imagen']['error'] != UPLOAD_ERR_OK) {
        echo 'Error: ';
        switch ($_FILES['imagen']['error']) {
            case UPLOAD_ERR_INI_SIZE:
            case UPLOAD_ERR_FORM_SIZE:
                echo 'El fichero es demasiado grande';
                break;
            case UPLOAD_ERR_PARTIAL:
                echo 'El fichero no se ha podido subir entero';
                break;
            case UPLOAD_ERR_NO_FILE:
                echo 'No se ha podido subir el fichero';
                break;
            default:
                echo 'Error indeterminado';
        }
    } elseif (is_uploaded_file($_FILES['imagen']['tmp_name']) === true) {
        $nombre = $_FILES['imagen']['name'];
        if (is_file($nombre) === true) {
            $nombre = time() . '_' . $nombre;
            //echo $nombre;
        }
        // echo "Entra";
        if (move_uploaded_file($_FILES['imagen']['tmp_name'], $nombre)) {
            //header("Content-type:" . $_FILES['imagen']['type']);
            $fp = fopen($nombre, 'rb');
            $contenido = fread($fp, filesize($nombre));
            fclose($fp);
            // echo $contenido;
            miniatura($nombre, "muestra120.jpg", 120, 120);
            miniatura($nombre, "muestra200.jpg", 200, 200);
        } else {
            echo 'Error: No se puede mover el fichero a su destino.';
        }
        // echo $_FILES['imagen']['type'];
    } else {
        echo 'Error: posible ataque. Nombre: ' . $_FILES['imagen']['name'];
    }
}
?>
<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Ejercicio 2</title>
</head>

<body>
    <form action=" " method="post" enctype="multipart/form-data">
        <input type="file" name="imagen" id="imagen">
        <br>
        <input type="submit" value="subir" name="subir">
        <br><br><br>
        <img src="muestra120.jpg" alt="img">
        <img src="muestra200.jpg" alt="img">
    </form>

</body>

</html>