<?php
session_start();


if (isset($_POST['enviar'])) {
    if ($_POST['text'] != $_SESSION['key']) {
        die("Error: No has introducido el código correcto.");
    } else {
        echo 'Correcto, parece que eres un humano.';
    }
}
?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Ejecicio Captcha</title>
</head>

<body>
    <form action=" " method="post">
        <img src="./captcha.php" alt="img">
        <br>
        <br>
        <input type="text" name="text" id="text">
        <input type="submit" name="enviar" value="enviar"></form>

</body>

</html>