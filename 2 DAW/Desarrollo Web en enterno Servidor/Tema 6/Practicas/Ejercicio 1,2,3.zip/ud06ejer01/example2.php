<?php
// a. Creación y configuración del lienzo
$alto = 300;
$ancho = 300;
$imagen = imagecreatetruecolor($ancho, $alto);
$black = imagecolorallocate($imagen, 0, 0, 0);
$green = imagecolorallocate($imagen, 204, 237, 121);
// b. Dibujamos la imagen
imagefill($imagen, 0, 0, $green);
imageline($imagen, 100, 100, 100, 200, $black);
imageline($imagen, 100, 100, 200, 100, $black);
imageline($imagen, 100, 200, 200, 200, $black);
imageline($imagen, 200, 100, 200, 200, $black);
imageline($imagen, 200, 100, 100, 200, $black);


imagestring($imagen, 5, 150, 200, 'DWES', $blanco);
imagestring($imagen, 5, 100, 85, 'DWES', $blanco);


// c. Generación de la imagen
header('content-type: image/png');
imagepng($imagen);
// d. Liberamos la imagen de memoria
imagedestroy($imagen);
