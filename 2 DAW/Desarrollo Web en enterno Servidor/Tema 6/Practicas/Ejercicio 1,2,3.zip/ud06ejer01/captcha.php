<?php

session_start();
$crypt = md5(mktime() * rand());

$string = substr($crypt, 0, 5);

$captcha = imagecreatefromjpeg("download.jpeg");
$red = imagecolorallocate($captcha, 255, 0, 0);
imageline($captcha, 100, 45, 39, 29, $red);
imageline($captcha, 400, 54, 64, 129, $red);
imageline($captcha, 404, 22, 64, 229, $red);
imageline($captcha, 40, 98, 64, 329, $red);
imageline($captcha, 100, 777, 39, 29, $red);
imageline($captcha, 450, 67, 64, 129, $red);
imageline($captcha, 404, 745, 64, 229, $red);
imageline($captcha, 40, 134, 64, 329, $red);
imageline($captcha, 234, 12, 39, 29, $red);
imageline($captcha, 400, 31, 456, 129, $red);
imageline($captcha, 404, 87, 45, 229, $red);
imageline($captcha, 40, 234, 87, 329, $red);
imageline($captcha, 654, 654, 234, 29, $red);
imageline($captcha, 234, 500, 60, 129, $red);
imageline($captcha, 8, 992, 61, 229, $red);
imageline($captcha, 34, 0, 123, 329, $red);

imagestring($captcha, 100, 100, 30, $string, $red);
$_SESSION['key'] = $string;
header("Content-type: image/jpeg");
imagejpeg($captcha);
imagedestroy(($captcha));
