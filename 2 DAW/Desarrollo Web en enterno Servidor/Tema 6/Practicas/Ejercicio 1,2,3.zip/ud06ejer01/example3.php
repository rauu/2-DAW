<?php
    // Creamos una imagen cargándola desde el archivo gif
$img_org = imagecreatefromgif("goodbye-homer.gif");
    // Obtenemos la mitad de las dimensiones de la imagen origen
$ancho_dst = intval(imagesx($img_org) * 2); $alto_dst = intval(imagesy($img_org) * 3.5);
    // Creamos un lienzo para la imagen destino con las dimensiones calculadas
$img_dst = imagecreatetruecolor($ancho_dst, $alto_dst);
/* Escalamos la imagen gif origen sobre la imagen nueva destino especificando punto 
de inicio para destino y origen, y punto final para destino y origen. */


//PREGUNTAR A MIGUEL. LA OPACIDAD NO VA
//imagecolorallocatealpha($img_dst, 0,0,0,137);

// TAMPOCO




imagecopyresampled($img_dst, $img_org, 30, 0, 30, 0, $ancho_dst, $alto_dst, imagesx($img_org), imagesy($img_org));


$img = imagerotate ( $img_dst, 45, 3);

    // Damos salida a la imagen final cambiando el formato a png
header("Content-type: image/png"); 
imagepng($img);
    // Destruimos ambas imágenes
imagedestroy($img_org);
imagedestroy($img_dst);
