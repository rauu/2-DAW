<?php
$estampa = imagecreatetruecolor(200, 100);

$img = imagecreatefromjpeg('image1.jpeg');
$margen_dcho = 1000;
$margen_inf = 700;
$sx = imagesx($estampa);
$sy = imagesy($estampa);
imagefilledrectangle($estampa, 4, 4, 400, 600, 0x0000FF);
imagefilledrectangle($estampa, 9, 9, 400, 600, 0xFFFFFF);
imagestring($estampa, 50, 70, 40, 'DAWES', 0x0000FF);
imagestring($estampa, 50, 70, 60, '2019-2020', 0x000000);
imagecopymerge(
     $img,
     $estampa,
     imagesx($img) - $sx - $margen_dcho,
     imagesy($img) - $sy - $margen_inf,
     0,
     0,
     imagesx($estampa),
     imagesy($estampa),
     500
);

header('Content-type: image/png');
imagepng($img);
imagepng($img, './cueva_registrada.png');
imagedestroy($img);
