<?php


// Una imagen simple


$imagen = imagecreatefromjpeg("image1.jpeg");
header("Content-Type: image/jpeg");
imagepng($imagen);
imagedestroy($imagen);
