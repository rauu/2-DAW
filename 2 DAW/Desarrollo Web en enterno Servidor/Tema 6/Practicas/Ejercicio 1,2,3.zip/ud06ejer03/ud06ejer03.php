<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Ejercicio 3</title>
</head>

<body>

    <form action=" " method="post" enctype="multipart/form-data">

        <label for="id">Id: </label>
        <input type="text" name="id" id="id" value="<?php if (isset($_POST['id'])) echo $_POST['id']; ?>">

        <?php
        if (isset($_POST['enviar']) && empty($_POST['id']))
            echo "<span style='color:red'>&#8592; ¡Debes introducir un Id!!</span>";
        ?>

        <br><br>


        <label for="titulo">Titulo: </label>
        <input type="text" name="titulo" id="titulo" value="<?php if (isset($_POST['titulo'])) echo $_POST['titulo']; ?>">

        <?php
        if (isset($_POST['enviar']) && empty($_POST['titulo']))
            echo "<span style='color:red'>&#8592; ¡Debes introducir un Titulo!!</span>";
        ?>

        <br><br>


        <label for="autor">Autor: </label>
        <input type="text" name="autor" id="autor" value="<?php if (isset($_POST['autor'])) echo $_POST['autor']; ?>">


        <?php
        if (isset($_POST['enviar']) && empty($_POST['autor']))
            echo "<span style='color:red'>&#8592; ¡Debes introducir un Autor!!</span>";
        ?>

        <br><br>


        <label for="paginas">Paginas: </label>
        <input type="text" name="paginas" id="paginas" value="<?php if (isset($_POST['paginas'])) echo $_POST['paginas']; ?>">

        <?php
        if (isset($_POST['enviar']) && empty($_POST['paginas']))
            echo "<span style='color:red'>&#8592; ¡Debes introducir un Paginas!!</span>";
        ?>

        <br><br>

        <label for="Imagen">Imagen: </label>
        <input type="file" name="foto" id="imagen">


        <br><br>


        <button type="submit" name="enviar">Introducir libro</button>


    </form>

    <br><br><br>

    <?php
    // La conexion a la BBDD
    include_once("conexion.php");

    $conection = new Conexion();

    //Function para insert libros
    function insertarProduct($id, $titulo, $autor, $paginas, $foto, $conection)
    {

        $conexion = $conection->getConexion();

        $sql = "INSERT INTO libros (id, titulo, autor, paginas, foto) 
                VALUES (:id, :titulo, :autor, :paginas, :foto)";

        $resultado = $conexion->prepare($sql);
        $resultado->bindParam(':id', $id);
        $resultado->bindParam(':titulo', $titulo);
        $resultado->bindParam(':autor', $autor);
        $resultado->bindParam(':paginas', $paginas);
        $resultado->bindParam(':foto', $foto);



        if (!$resultado) {
            $mensaje = "Error al crear el registro";
        } else {
            $resultado->execute();

            $mensaje = "Registro creado correctamente";
        }
        //echo $mensaje;
        return $mensaje;
    }

    //If en el caso que de que si todos los campos tiene algun valor pues que me inserte datos
    if (!empty($_POST['id']) && !empty($_POST['titulo']) && !empty($_POST['autor']) && !empty($_POST['paginas'])) {


            $name = addslashes($_FILES['foto']['name']);
            $image = addslashes($_FILES['foto']['tmp_name']);
            $image=file_get_contents($image);
            $image=base64_encode($image);
            //echo $image;
            echo insertarProduct($_POST['id'], $_POST['titulo'], $_POST['autor'], $_POST['paginas'], $image, $conection);
            header('Location: ./ud06ejer03.php');

       
    }


    ?>

    <table border>

        <tr>
            <th>ID</th>
            <th>Titulo</th>
            <th>AUTHOR</th>
            <th>PAGINAS</th>
            <th>FOTO</th>

        </tr>
        <?php
        function select($conection)
        {
            $conexion = $conection->getConexion();

            $sql = "SELECT * FROM libros";
            $resultado = $conexion->prepare($sql);
            $resultado->execute();
            $rows = null;
            while ($fila = $resultado->fetch()) {
                $src = '<img width = 250 height = 125 src = "data:image; base64, '.$fila['foto'].'">';
                // guardamos las filas en un array
                $rows = $rows . "<tr><td>" . $fila['id'] . "</td> <td>" . $fila['titulo'] . "</td> <td>" . $fila['autor'] . "</td> 
                <td>" . $fila['paginas'] . "</td> <td>" . $src . "</td></tr>";
            }
            return $rows;
        }
        echo select($conection);
        ?>


    </table>

    <?php



    //$conexion->close();
    ?>
    <style>
        form {
            justify-content: center;
        }

        button {
            height: 3em;
            width: 7em;
            background-color: #c5c7c5;
        }

        #buscar {
            height: 2.5em;
        }

        img {
            width: 200px;
            height: 200px;
        }
    </style>
</body>

</html>