<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
</head>

<body>

</body>

</html>

<?php

include_once("conexion.php");

$conection = new Conexion();

function select($conection)
{
    $conexion = $conection->getConexion();

    $sql = "SELECT * FROM libros ";
    $resultado = $conexion->prepare($sql);
    $resultado->execute();
    $rows = null;
    while ($fila = $resultado->fetch()) {
        // guardamos las filas en un array
        $rows = $rows . "<tr><td>" . $fila['id'] . "</td> <td>" . $fila['titulo'] . "</td> <td>" . $fila['autor'] . "</td> 
         <td>" . $fila['paginas'] . "</td> <td><img src=\"" . $fila['foto'] . "\"> </td></tr>";
    }
    return $rows;
}
echo select($conection);

?>