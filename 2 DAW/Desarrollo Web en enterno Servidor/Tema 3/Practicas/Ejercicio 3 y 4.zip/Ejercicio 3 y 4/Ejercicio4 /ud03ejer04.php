<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Ejercicio 4</title>
</head>
<body>
    <?php
        include('contacto.php');
        include('agenda.php');

        $contact1 = new Contacto("001", "Raunak", "987654321");
        $contact2 = new Contacto("002", "Victor", "123456779");
        $contact3 = new Contacto("003", "Lucia", "234567844");
       
        $contact1->id ="001";
        $contact1->name ="Raunak";
        $contact1->telefono ="99034432";
        
        $contact2->id ="002";
        $contact2->name ="Victor";
        $contact2->telefono ="998";
        
        
        $contact3->id ="003";
        $contact3->name ="Lucia";
        $contact3->telefono ="345435345345";
        

        $agenda = new Agenda();
        $agenda->anyadir($contact1);
        $agenda->anyadir($contact2);
        $agenda->anyadir($contact3);
        

        ?>
        <table border>
    
            <?php
              echo $agenda->mostrar_datos();
            ?>
        </table>
    
        <?php
        
        //$clone = clone $agenda;


    //Cambio el nombre de contacto1 para comprobar si se ha clonado 
       /* $contact1->name = "Patata";

        echo "<strong>Agenda sin clonar</strong> <br> <br>";
        echo print_r($agenda);
        echo "<br> <br>";

        

        echo"<strong>Agenda clonada</strong>  <br> <br>";
        echo print_r($clone);*/
    ?>
    
</body>
</html>