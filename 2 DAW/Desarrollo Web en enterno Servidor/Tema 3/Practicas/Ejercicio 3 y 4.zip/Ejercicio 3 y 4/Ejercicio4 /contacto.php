<?php
class Contacto
{
    private $id;
    private $name;
    private $telefono;


    public function __construct($id, $name, $telefono)
    {
        $this->id = $id;
        $this->name = $name;
        $this->telefono = $telefono;
    }

    public function __get($name)
    {
        switch ($name) {
            case 'id':
                return $this->id;
            case 'name':
                return $this->name;
            case 'telefono':
                return $this->telefono;
        }
    }

    public function __set($name, $value){
        switch($name){
            case 'id':
                $this->id = $value;
                break;
            case 'name':
                $this->name = $value;
                break;
            case 'telefono':
                $this->telefono = $value;
        }
    }

    /*public function setId($id)
    {
        $this->id = $id;
    }

    public function getId()
    {
        return $this->id;
    }
    public function setName($name)
    {
        $this->name = $name;
    }

    public function getName()
    {
        return $this->name;
    }
    public function setTelefono($telefono)
    {
        $this->telefono = $telefono;
    }

    public function getTelefono()
    {
        return $this->telefono;
    }*/

    public function __toString()
    {
        return "El Nombre es: " . $this->name . " y el telefono es:(" . $this->telefono . ")";
    }
}
