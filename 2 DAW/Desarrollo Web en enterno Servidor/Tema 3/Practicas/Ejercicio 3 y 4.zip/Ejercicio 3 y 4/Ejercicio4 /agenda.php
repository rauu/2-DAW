<?php

    class Agenda{

        private $arrayContacto = [];

        
        
        public function anyadir($contacto){
            $this->arrayContacto[$contacto->id] = $contacto;
        }

        public function eliminar($id){
        //    unset($this->arrayContacto[$id]);
            
        }


        /*public function __clone(){
            foreach($this->arrayContacto as $key => $value){
                $this->arrayContacto[$key] = clone $value;
            }
            
        }*/

        public function mostrar_datos(){
            
            $text = " ";
            $text .= "<tr>";
            $text .= "<th>Nombre</th>";
            $text .= "<th>Id</th>";
            

            foreach ($this->arrayContacto as $value) {
                $text .=  "<tr>";
                $text .=  "<td>".$value->name."</td>";
                $text .=  "<td><a href = \"info_contacto.php?name=$value->name&id=$value->id&telefono=$value->telefono\">Ver Contacto</a></td>";
                $text .=  "</tr>";
            }
            

            return $text;


        }


        public function __toString()
        {
           
        }

        

    }



    /* $text =" ";
            $text .= "<tr>";
            $text .=  "<th>Id</th>";
            $text .=  "<th>Nombre</th>";
            $text .=  "<th>Telefono</th>";
            $text .=  "</tr>";

            foreach ($this->arrayContacto as $value) {
                $text .=  "<tr>";
                $text .=  "<td>".$value->id."</td>";
                $text .=  "<td>".$value->name."</td>";
                $text .=  "<td>".$value->telefono."</td>";
                $text .=  "</tr>";
            }
            
            return $text;*/
?>




