<?php

$name = $_GET['name'];
$id = $_GET['id'];
$telefono = $_GET['telefono'];

    //$name = $_GET[$y->name];
    echo "Nombre: ".$name." <br>";
    echo "Id: ".$id." <br>";
    echo "Telefono: ".$telefono."<br>";

?>