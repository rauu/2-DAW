for (var x = 1; x <= 25; x++) {
    document.write(11 * x);
    if (x < 25) {
        document.write(" - ");
    }
}