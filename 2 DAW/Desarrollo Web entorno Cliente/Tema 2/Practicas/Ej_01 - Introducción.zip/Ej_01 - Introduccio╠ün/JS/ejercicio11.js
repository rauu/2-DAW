var numNaN = 0,
    par = 0,
    impar = 0,
    entero = 0,
    decimal = 0,
    num;

do {
    num = parseFloat(prompt("Indruduzca un numero entero. Para cerrar el programa introduzca 0"));
    if (!isNaN(num)) {
        if (Number.isInteger(num)) {
            if (num != 0) {
                entero++;
                if (num % 2 == 0) {
                    par++;
                } else {
                    impar++;
                }
            }
        } else {
            decimal++;
        }
    } else {
        numNaN++;
    }
}
while (num != 0);

document.write("<strong>Numeros enteros</strong></br>");
document.write("Hay " + entero + " numeros enteros en total </br>");
document.write("Numeros pares: " + par + "</br>");
document.write("Numeros impar: " + impar + "</br></br>");

document.write("<strong>Numeros decimales</strong></br>");
document.write("Hay " + decimal + " numeros decimales </br></br>");

document.write("<strong>Numeros Erróneos</strong></br>");
document.write("Hay " + numNaN + " numeros erróneos");