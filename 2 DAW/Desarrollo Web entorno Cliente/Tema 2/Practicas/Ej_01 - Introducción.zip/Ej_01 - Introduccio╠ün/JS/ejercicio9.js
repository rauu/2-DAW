function nota() {
    var nombre = prompt("Escriba el nombre de alumno");
    var nota1 = parseInt(prompt("Escriba la nota 1 del " + nombre + " en entero"));
    var nota2 = parseInt(prompt("Escriba la nota 2 del " + nombre + " en entero"));
    var nota3 = parseInt(prompt("Escriba la nota 3 del " + nombre + " en entero"));

    if (!isNaN(nota1, nota2, nota3)) {
        var nota_media = (nota1 + nota2 + nota3) / 3;
        if (nota_media >= 7) {
            document.write("Promociona");
        } else {
            document.write("No promociona");
        }
    } else {
        alert("Has instruducido un valor mal");
    }
}

nota();