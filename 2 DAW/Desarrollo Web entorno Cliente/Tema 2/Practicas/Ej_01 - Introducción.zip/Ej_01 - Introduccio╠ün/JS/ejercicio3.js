
document.write("Mi nombre es: Raunak Binyani");
document.write("</br>");
document.write("Tengo 19 años");