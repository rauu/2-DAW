var num1 = parseFloat(prompt("Dime un numero 1"));

var num2 = parseFloat(prompt("Dime numero 2"));


if(isNaN(num1) || isNaN(num2)){
    alert("Has introducido un numero mal");
} else{
    alert("La suma es: " + (num1 + num2) + ".");
}