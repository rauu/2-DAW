var num2 = 0;
do {
    var num1 = parseFloat(prompt("Inroduzca un numero. Si quiere cerrar el programa indruduzca 0."));

    if (!isNaN(num1)) {

        if (num2 < num1 || num2 == 0) {
            num2 = num1;
        }
    } else {
        alert("No puede introducir letras o caracteres especiales. Solo numeros enteros");
    }
}
while (num1 != 0);
document.write("El numero mayor es " + num2);