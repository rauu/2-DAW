var nombre = prompt("Escriba su nombre");

var edad = prompt("Escriba su edad");

var estado_civil = prompt("Escriba su estado civil");

alert("Su nombre es " + nombre + " tiene " + edad + " años y su estado civil es " + estado_civil + ".");





