function ingresar() {
    var num;
    do {
        num = parseInt(prompt("Dime un numero entre 1 y 5. Para cerrar el programa introduce 0"));

        if (num >= 1 && num <= 5) {
            alert("Has introducido " + num);
        } else if (num == 0) {
            break;
        } else {
            alert("ERROR: El número introducido no se encuentre en dicho rango.");
        }
    } while (num != 0);
}

ingresar();