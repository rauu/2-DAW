let img = ["../IMG/img1.jpg", "../IMG/img2.jpg", "../IMG/img3.jpg", "../IMG/img4.jpg", "../IMG/img5.jpg"];
let value1 = 1;
let value2 = 2;
let value3 = 0;



function next() {
    let image1 = document.getElementById("image1");
    let image2 = document.getElementById("image2");
    let image3 = document.getElementById("image3");
    if (value1 < img.length - 1) {
        value1 = value1 + 1;
    } else {
        value1 = 0;
    }
    if (value2 < img.length - 1) {
        value2 = value2 + 1;
    } else {
        value2 = 0;
    }
    if (value3 < img.length - 1) {
        value3 = value3 + 1;
    } else {
        value3 = 0;
    }




    image2.setAttribute("src", img[value1]);
    image3.setAttribute("src", img[value2]);
    image1.setAttribute("src", img[value3]);


}


function previous() {
    let image1 = document.getElementById("image1");
    let image2 = document.getElementById("image2");
    let image3 = document.getElementById("image3");

    if (value1 > 0) {
        value1 = value1 - 1;

    } else {
        value1 = img.length - 1;
    }
    if (value2 > 0) {
        value2 = value2 - 1;

    } else {
        value2 = img.length - 1;
    }
    if (value3 > 0) {
        value3 = value3 - 1;

    } else {
        value3 = img.length - 1;
    }
    image2.setAttribute("src", img[value1]);
    image3.setAttribute("src", img[value2]);
    image1.setAttribute("src", img[value3]);
}
let interval;

function empezar() {
    interval = setInterval(next, 900);
}

function parar() {
    console.log("dnafsdasfo " + interval);
    clearInterval(interval);

}