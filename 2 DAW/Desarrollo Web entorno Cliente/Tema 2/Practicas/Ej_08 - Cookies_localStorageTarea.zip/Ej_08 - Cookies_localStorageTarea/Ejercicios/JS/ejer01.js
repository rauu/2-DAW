//Funcion para añadir las cookies
//Para el botón Añadir, pida por el prompt cuantas cookies queremos crear
//y luego nos pida para cada cookie los siguientes valores: “Nombre”, “Valor”, “Caducidad”.


let array_cookies = [];

function Anyadir() {

    //Prompt para saber cauntas cookies quiere crear el usuario
    let num_cookies = parseInt(prompt("Cuantas cookies quiere crear?"));
    if (!isNaN(num_cookies)) {

        for (let i = 0; i < num_cookies; i++) {
            let cookie_name = prompt("Escriba el nombre de cokkie numero " + (i + 1));
            let cookie_value = prompt("Escriba el valor que quiera poner al cokkie numero " + (i + 1));
            let cookie_expire = prompt("Esciba el la de cacducidad del cookie numero (en dias) " + (i + 1));


            // Creo una nueva fecha
            let date = new Date();


            if (isNaN(cookie_expire)) {
                alert("Como ha escrito un valor por incorrecto pues la fecha de caducidad es por defecto");
                date.setTime(date.getTime() + (7 * 24 * 60 * 60 * 1000));
                var expires = "expires=" + date.toUTCString();
                document.cookie = cookie_name + "=" + cookie_value + ";" + expires + ";path=/";
            } else {
                date.setTime(date.getTime() + (cookie_expire * 24 * 60 * 60 * 1000));
                var expires = "expires=" + date.toUTCString();
                document.cookie = cookie_name + "=" + cookie_value + ";" + expires + ";path=/";
            }
        }


    }
}


function Consultar() {
    //document.write(document.cookie);

    miscookies = getcookies();
    if (miscookies !== null) {
        document.write("<h1>Cookies</h1>");
        for (var a in miscookies) {
            document.write(a + " =  " + miscookies[a]);
            document.write("<br>");
            document.write("<br>");
        }
    } else document.write("no hay cookies");
}

function Modificar() {

    var cookie_name = prompt("Escriba el nombre de la cookie que quieres modficiar");
    var cookie_value = prompt("Escriba el nuevo valor de la cookie");
    var cookie_expire = prompt("Esciba el la de cacducidad del cookie numero (en dias)");
    var date = new Date();

    if (isNaN(cookie_expire)) {
        alert("Tienes que insertar un numero en la fecha");
    } else {
        date.setTime(date.getTime() + (date * 24 * 60 * 60 * 1000));
        var expires = "expires=" + date.toUTCString();
        document.cookie = "\"" + cookie_name + "=" + cookie_value + ";" + expires + "; path=\"";

    }

}

function Borrar() {
    var cookie_name = prompt("Escriba el nombre de la cookie que quieres eliminar");
    document.cookie = "\"" + cookie_name + "=" + ";" + "expires=01 Jan 1970 00:00:00 UTC; path=\"";

}


function getcookies() {
    var micoo = null;
    var cadena = document.cookie;
    var miarray = "";
    var mimini;
    if (cadena.trim().length > 0) {
        miarray = cadena.split(";");
        micoo = {};
        for (a = 0; a < miarray.length; a++) {
            mimini = miarray[a].split("=");
            micoo[mimini[0].trim()] = mimini[1].trim();
        }
    }
    return micoo;

}