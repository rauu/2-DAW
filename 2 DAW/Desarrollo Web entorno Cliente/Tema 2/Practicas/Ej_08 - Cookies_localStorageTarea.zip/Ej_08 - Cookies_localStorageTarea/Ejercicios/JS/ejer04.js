//Creacion de COOKIE


function Dni() {

    let dni_value = document.getElementById('dni').value;

    if (dni_value == "") {
        alert("No has escrito nada");
    } else {
        let dni = dni_value.toUpperCase();
        let num = dni.slice(0, 8);
        let caracter = dni.slice(8, 9);
        var letters = ["T", "R", "W", "A", "G", "M", "Y", "F", "P", "D", "X", "B", "N", "J", "Z", "S", "Q", "V", "H", "L", "C", "K", "E"];

        if (isNaN(num)) {

        } else {
            var result = num % 23;
            var ans = letters[result];

            if (ans != caracter) {
                alert("El dni esta mal");

            } else {

                alert("Se ha creado el cookie");

                var expires = "expires=Fri, 01 Jan 2021 00:00:00 UTC";
                document.cookie = "Dni" + "=" + dni_value + ";" + expires + ";path=/";

            }
        }
    }
}