var form = document.getElementById('form');
var nombre = form.nombre;
var apellido = form.apellido;
var dni = form.dni;
var correo = form.correo;


function guardar() {
    // alert("daf");
    console.log(nombre.value);
    sessionStorage.setItem("Nombre", nombre.value);
    sessionStorage.setItem("Apellido", apellido.value);
    sessionStorage.setItem("Dni", dni.value);
    sessionStorage.setItem("Correo", correo.value);

}

function recuperar() {

    nombre.value = sessionStorage.getItem('Nombre');
    apellido.value = sessionStorage.getItem('Apellido');
    dni.value = sessionStorage.getItem('Dni');
    correo.value = sessionStorage.getItem('Correo');
}

function borrar() {
    sessionStorage.clear();
}