var form = document.getElementById('form');
var nombre = form.nombre;
var apellido = form.apellido;
var nif = form.dni;
var correo = form.correo;


function guardar() {
    // alert("daf");
    console.log(nombre.value);
    localStorage.setItem("Nombre", nombre.value);
    localStorage.setItem("Apellido", apellido.value);
    localStorage.setItem("Dni", dni.value);
    localStorage.setItem("Correo", correo.value);

}

function recuperar() {

    nombre.value = localStorage.getItem('Nombre');
    apellido.value = localStorage.getItem('Apellido');
    dni.value = localStorage.getItem('Dni');
    correo.value = localStorage.getItem('Correo');
}

function borrar() {
    localStorage.clear();
}