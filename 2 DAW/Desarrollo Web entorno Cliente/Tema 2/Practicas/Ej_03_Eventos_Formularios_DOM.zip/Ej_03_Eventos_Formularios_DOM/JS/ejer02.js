function p1() {
    let p = document.getElementById("p1");
    p.style.color = "red";

}

function p2() {
    let p = document.getElementById("p2");
    p.style.color = "blue";

}

function p3() {
    let p = document.getElementById("p3");
    p.style.color = "green";

}

function p4() {
    let p = document.getElementById("p4");
    p.style.color = "yellow";

}

function p5() {
    let p = document.getElementById("p5");
    p.style.color = "white";

}