var cont = 0;
var num = 2;

function primos(num) {
    for (var x = 2; x < num; x++) {
        if (num % x == 0) {
            return false;
        }
    }
    return true;
}

document.write("Los 100 primeros numeros primos son: ");
while (cont < 100) {
    if (primos(num)) {
        document.write(num + "<br />");
        cont++;
    }
    num++;
}

primos();






/*for (var x = 2; x < num; x++) {
    if (num % x === 0) {
        primo = false;
    }
}*/

/*if (primo == true) {
    alert("true");
} else {
    alert("false");
}*/