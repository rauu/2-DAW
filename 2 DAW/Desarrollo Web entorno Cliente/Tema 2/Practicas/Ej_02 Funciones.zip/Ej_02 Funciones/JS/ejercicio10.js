function table() {
    var td = document.getElementsByTagName("td");
    for (var i = 0; i < td.length; i++) {
        if (i != 4 && i != 9 && i != 14 && i < 15) {
            td[i].innerHTML = prompt("Escriba el contenido de la celda " + (i + 1));

            if (isNaN(td[i].innerHTML)) {
                alert("No puede escribir letras");
                break;
            }

        } else if ((i == 4 || i == 9 || i == 14) && i < 15) {

            td[i].innerHTML = parseFloat(td[i - 1].innerHTML) + parseFloat(td[i - 2].innerHTML) + parseFloat(td[i - 3].innerHTML) + parseFloat(td[i - 4].innerHTML);

        } else if (i > 14) {
            var test = 0;
            for (var j = (i - 5); j >= (i - 15); j = j - 5) {

                test = test + parseFloat(td[j].innerHTML);
            }

            td[i].innerHTML = test;

        }

        if (i == 19) {
            td[i].innerHTML = parseFloat(td[i].innerHTML) + parseFloat(td[i - 1].innerHTML) + parseFloat(td[i - 2].innerHTML) + parseFloat(td[i - 3].innerHTML) + parseFloat(td[i - 4].innerHTML);
        }
    }



}

table();