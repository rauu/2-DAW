function array_elementos() {
    var text;
    var array1 = [];
    var array2 = [];
    var array3 = [];

    while (text != 0) {
        text = prompt("Escribe un texto o numero y para cerrar el programa pulse 0");
        array1.push(text);
    }

    for (var x = 0; x < array1.length; x++) {
        if (!isNaN(array1[x])) {
            array2.push(array1[x]);
        } else {
            array3.push(array1[x]);
        }
    }
    console.log(array1);
    document.write("Todos los numeros: " + array2 + "</br>");
    document.write("Todos lso alfaumericos: " + array3);

}

array_elementos();