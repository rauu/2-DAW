var num1 = parseFloat(prompt("Escribe el primero numero"));
var num2 = parseFloat(prompt("Escribe el segundo numero"));
var suma, resta, divi, multi;

function sumar(num1, num2) {
    suma = num1 + num2;
    return suma;
}

function restar(num1, num2) {
    resta = num1 - num2;
    return suma;
}

function dividir(num1, num2) {
    divi = num1 / num2;
    return suma;
}

function multiplicar(num1, num2) {
    multi = num1 * num2;
    return suma;
}

function calcular() {
    sumar(num1, num2);
    restar(num1, num2);
    dividir(num1, num2);
    multiplicar(num1, num2);

    document.write("La suma de " + num1 + " y " + num2 + " es: " + suma + "</br>");
    document.write("La resta de " + num1 + " y " + num2 + " es: " + resta + "</br>");
    document.write("La division de " + num1 + " y " + num2 + " es: " + divi + "</br>");
    document.write("La multiplicacion de " + num1 + " y " + num2 + " es: " + multi + "</br>");
}

calcular();