var c = parseFloat(prompt("Escrima la temperatura en Celsius"));
var f = parseFloat(prompt("Escrima la temperatura en Fahenheit"));

var resultC, resultF;

function sacar_celcius(f) {

    resultC = ((f - 32)) * 5 / 9;
    return resultC;

}

function sacar_fahenheit(c) {
    resultF = (c * 9 / 5) + 32;
    return resultF;
}

function mostrar() {
    sacar_celcius(f);
    sacar_fahenheit(c);
    document.write(c + "º C es " + resultF + "º F</br>");
    document.write(f + "º F es " + resultC + "º C");

}

mostrar();