function array() {
    var num;
    var par = [];
    var impar = [];
    while (num != 0) {
        num = prompt(("Escriba un numero"));


        if (num != 0) {
            if (num % 2 == 0 && !isNaN(num)) {
                par.push(num);

            } else if (num % 2 != 0 && !isNaN(num)) {
                impar.push(num);
            }
        }


    }

    document.write(par + "," + impar);
}

array();