function palindromo() {
    var text = prompt("Escriba un texto");
    var palintext = text.split(" ").join("").split("").reverse().join("");
    var palin = text.split(" ").join("");
    if (palin == palintext) {
        alert("Es palíndromo");
    } else {
        alert("No es palíndromo");
    }

    document.write(text);
}

palindromo();



/*
function palindromo() {
    var text = prompt("Escribe un texto");

    var t = text.split("").reverse().join("");
    document.write(t);

    var palin = t;
    var textpalin = text;
    textpalin.replaceAll(" ", "").split(" ").join("");
    palin.replaceAll(" ", "").split(" ").join("");
    console.log(textpalin);
    console.log(palin);

    /*if (textpalin == palin) {
        alert("Es palindromo");
    } else {
        alert("No es palindromo");
    }

}
palindromo();
*/