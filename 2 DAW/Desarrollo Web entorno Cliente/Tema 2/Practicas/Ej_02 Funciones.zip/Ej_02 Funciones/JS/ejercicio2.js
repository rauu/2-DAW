function search() {
    var string = prompt("Escriba un texto");
    document.write(string + "</br>");

    var text_search = prompt("Escriba la palabra que quiere buscar.");
    document.write(string.replaceAll(text_search, ('<u>' + text_search + '</u>')));

}

search();