function fecha_valid() {
    var date = prompt("Escribe una fecha");

    var split_Date = date.split("");

    //var b = false;
    var cont = 0;
    for (var x = 0; x < split_Date.length; x++) {
        if (split_Date[x] == "/") {
            cont++;
        }
    }

    if (cont == 2) {
        var date2 = date.split("/");
        var day = date2[0];
        var month = date2[1];
        var year = date2[2];
        var dateDay = date2[1] + "/" + date2[0] + "/" + date2[2];
        var fecha = new Date(dateDay);

        //switch para Dias
        var dias = fecha.getDay();
        var meses = fecha.getMonth();

        switch (dias) {
            case 0:
                dias = "Domingo";
                break;
            case 1:
                dias = "Lunes";
                break;
            case 2:
                dias = "Martes";
                break;
            case 3:
                dias = "Miercoles";
                break;

            case 4:
                dias = "Jueves";
                break;

            case 5:
                dias = "Viernes";
                break;

            case 6:
                dias = "Sabado";
                break;

        }

        switch (meses) {
            case 0:
                meses = "Enero";
                break;
            case 1:
                meses = "Febrero";
                break;
            case 2:
                meses = "Marzo";
                break;
            case 3:
                meses = "Abril";
                break;
            case 4:
                meses = "Mayo";
                break;
            case 5:
                meses = "Junio";
                break;
            case 6:
                meses = "Julio";
                break;
            case 7:
                meses = "Agosto";
                break;
            case 8:
                meses = "Septiembre";
                break;
            case 9:
                meses = "Octubre";
                break;
            case 10:
                meses = "Noviembre";
                break;
            case 11:
                meses = "Deciembre";
                break;
        }

        if (day >= 1 && day <= 31 && month >= 1 && month <= 12 && year >= 1970 && year <= 2200) {

            document.write(date + "</br>");
            document.write(dias + ", " + fecha.getDate() + " de " + meses + " de " + fecha.getFullYear() + "</br>");
            document.write("El primer dia de mes es: 01 </br>");
            var lastday = new Date(year, month, 0).getDate();
            document.write("El ultimo dia de mes es: " + lastday);
        } else {
            alert("Fecha invalida");
        }

    } else {
        alert("Fecha invalida");
    }



}

fecha_valid();