function numArmstrong() {
    var bool = false;
    var num = prompt("Escriba un numero");
    var numS = num.split("");
    var solution = 0;
    console.log(numS);
    if (num >= 100 && num <= 999) {
        for (var x = 0; x < numS.length; x++) {
            solution += numS[x] ** 3;
            if (solution == num) {
                bool = true;
                document.write(num + " es un numero Armstrong");
                alert(bool);
            }
        }
        if (bool == false) {
            document.write(num + " no es un numero Armstrong");
            alert(bool);
        }
    } else {
        alert("Numero invalido");
    }
}

numArmstrong();