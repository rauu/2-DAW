import { EventFilterPipe } from './event-filter.pipe';

describe('EventFilterPipe', () => {
  it('create an instance', () => {
    const pipe = new EventFilterPipe();
    expect(pipe).toBeTruthy();
  });
});
