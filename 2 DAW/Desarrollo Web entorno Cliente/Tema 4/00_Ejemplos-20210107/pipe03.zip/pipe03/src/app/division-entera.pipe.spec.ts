import { DivisionEnteraPipe } from './division-entera.pipe';

describe('DivisionEnteraPipe', () => {
  it('create an instance', () => {
    const pipe = new DivisionEnteraPipe();
    expect(pipe).toBeTruthy();
  });
});
