import { Pipe, PipeTransform } from '@angular/core';
import { IProduct } from '../interfaces/i-product';
@Pipe({
  name: 'productFilter'
})
export class ProductFilterPipe implements PipeTransform {

  transform(products: IProduct[], filterBy: string): IProduct[] { const filter = filterBy ? filterBy.toLocaleLowerCase() : null; if (filter) {
    return products
    .filter(prod => prod.description.toLocaleLowerCase().includes(filter))
    }
    return products;
   }

}
