var ajax;
window.addEventListener("keyup", iniciar, false);


function iniciar() {
    var obj = document.getElementById("ciudad").value;
    ajax = new XMLHttpRequest();
    ajax.addEventListener("load", mostrar, false);

    ajax.open("GET", "php.php?letra=" + obj, true);

    ajax.send();

}

function mostrar(e) {
    var v_resultado = document.getElementById("resultado");
    //v_resultado.innerHTML = e.target.response;
    v_resultado.innerHTML = e.target.responseText;
}