<?php

$pais = ["Barcelona", "Madrid", "Valencia", "Mallorca", "Osasuna", "Alicante"];

$letra = $_GET['letra'];


echo "Sugerencias: ";
foreach ($pais as $x) {
    $pos = strpos(strtoupper($x), strtoupper($letra));
    if($pos !== false){
        echo $x.", ";
    }
}

