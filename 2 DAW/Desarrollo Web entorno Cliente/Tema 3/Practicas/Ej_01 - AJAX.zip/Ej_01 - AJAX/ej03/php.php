
<?php
$file = "data.json";


$formdata = $_POST['table'];

$myfile = fopen($file, 'w');
fwrite($myfile, $formdata);
fclose($myfile);