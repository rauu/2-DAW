var ajax;
window.addEventListener("load", inicia, false);

function inicia() {
    var obj = document.getElementById("enviar");
    obj.addEventListener("click", solAjax, false);
}

function solAjax() {
    let texto = document.getElementById("recurso").value;
    ajax = new XMLHttpRequest();
    ajax.addEventListener("load", mostrar, false);
    ajax.addEventListener("loadend", final, false);
    ajax.addEventListener("readystatechange", cambio, false);
    ajax.open("GET", texto, true);
    ajax.send();
}

function mostrar(e) {
    var v_resultado = document.getElementById("contenidos");
    v_resultado.innerText = e.target.responseText;
}

function text() {

}

function cambio(e) {
    let text = "";
    switch (ajax.readyState) {
        case 0:
            text = "Client has been created. open() not called yet.";
            break;
        case 1:
            text = "open() has been called.";
            break;
        case 2:
            text = "send() has been called, and headers and status are available.";
            break;
        case 3:
            text = "Downloading; responseText holds partial data.";
            break;
        case 4:
            text = "The operation is complete.";
            break;
    }

    document.getElementById("estados").innerHTML += ajax.readyState + ": " + text + "\n"; // variable pública console.log(e.target.readyState); // utilizar el objeto event.
    console.log('state: ' + ajax.readyState);
}



function final() {
    document.getElementById("codigo").innerHTML += ajax.status + ": " + ajax.statusText + "\n";
}